#include<bits/stdc++.h>

using namespace std;



int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    const int modulo = 1e9+7;
    cin>>n;
    vector<int> numbers(n);

    for(auto &x:numbers) cin>>x;

    // DP Problem, haven't read the chapter yet
}

